from pyspark.sql import SparkSession
from pyspark.sql.functions import col,avg
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("ActivePowerPrediction") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# Step 1: Load the Dataset
delta_table_path = "/home/xs-514ansana/delta/tables/new_wind_data"
data_df = spark.read.format("delta").load(delta_table_path)

# Step 2: Select Relevant Features and Target Variable
feature_columns = [
    "signals.Wind Speed (m/s)", 
    "signals.Theoretical_Power_Curve (KWh)", 
    "signals.Wind Direction (°)"
]
target_column = "signals.LV ActivePower (kW)"

selected_df = data_df.select(
    col("signal_date"),
    col("signal_ts"),
    col(target_column).alias("active_power"),
    *[col(c).alias(c.split(".")[-1]) for c in feature_columns]
)

# Step 3: Handle Missing Values (if any)
cleaned_df = selected_df.na.drop()  # Drop rows with null values

# Step 4: Prepare Data for Machine Learning
assembler = VectorAssembler(inputCols=["Wind Speed (m/s)", "Theoretical_Power_Curve (KWh)", "Wind Direction (°)"], outputCol="features")
prepared_df = assembler.transform(cleaned_df).select("features", "active_power")

# Step 5: Split Data into Training and Testing Sets
train_df, test_df = prepared_df.randomSplit([0.8, 0.2], seed=42)


# Check the size of the training dataset
train_count = train_df.count()
print(f"Number of rows in the training dataset: {train_count}")

# Check the size of the testing dataset
test_count = test_df.count()
print(f"Number of rows in the testing dataset: {test_count}")


# Step 6: Train the Model
lr = LinearRegression(featuresCol="features", labelCol="active_power")
lr_model = lr.fit(train_df)

# Step 7: Evaluate the Model
predictions = lr_model.transform(test_df)
evaluator = RegressionEvaluator(labelCol="active_power", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE): {rmse}")


# Calculate R-squared (Coefficient of Determination)
r2_evaluator = RegressionEvaluator(labelCol="active_power", predictionCol="prediction", metricName="r2")
r2 = r2_evaluator.evaluate(predictions)
print(f"\nR-squared (R2): {r2}")

# Step 1: Extract required fields from the signals MapType, including active_power
single_day_df = data_df.filter(col("signal_date") == "2018-02-01")  # Replace with desired date
single_day_df = single_day_df.select(
    col("signal_date"),
    col("signal_ts"),
    col("signals.`LV ActivePower (kW)`").alias("active_power"),  # Include the target column
    col("signals.`Wind Speed (m/s)`").alias("Wind Speed (m/s)"),
    col("signals.`Theoretical_Power_Curve (KWh)`").alias("Theoretical_Power_Curve (KWh)"),
    col("signals.`Wind Direction (°)`").alias("Wind Direction (°)")
)

# Ensure there are no missing values
single_day_df = single_day_df.na.drop()

# Assemble features for the single day
single_day_features = assembler.transform(single_day_df).select("features", "signal_date", "signal_ts", "active_power")

# Make predictions and include actual active power
single_day_predictions = lr_model.transform(single_day_features)

# Show predictions alongside actual values
print("\n=== Comparison of Predicted and Actual Active Power ===")
single_day_predictions.select("signal_date", "signal_ts", "active_power", "prediction").show(truncate=False)

# Aggregate actual and predicted values for the single day
single_day_aggregated = single_day_predictions.groupBy("signal_date").agg(
    avg("active_power").alias("actual_power"),
    avg("prediction").alias("predicted_power")
)
print("\n=== Aggregated Results for Single Day ===")
single_day_aggregated.show(truncate=False)

#graph the results


# import matplotlib.pyplot as plt


# # Visualization: Simplified Graph of Actual vs Predicted Daily Active Power
# # Visualization: Single-Day Graph
# single_day_pd = single_day_aggregated.toPandas()

# plt.figure(figsize=(8, 4))  # Keep the graph compact
# plt.bar(["Actual Power", "Predicted Power"], [single_day_pd["actual_power"][0], single_day_pd["predicted_power"][0]], color=["blue", "orange"])

# # Title and Labels
# plt.title("Actual vs Predicted Active Power for 2018-01-01")
# plt.ylabel("Active Power")
# plt.tight_layout()

# # Save or Show Plot
# plt.savefig("single_day_actual_vs_predicted.png")
# plt.show()


# pandas_df = predictions.select("active_power", "prediction").toPandas()

# import matplotlib.pyplot as plt
# plt.figure(figsize=(10, 6))
# plt.scatter(pandas_df["active_power"], pandas_df["prediction"], alpha=0.5, color="orange")
# plt.xlabel("Actual Active Power")
# plt.ylabel("Predicted Active Power")
# plt.title("Actual vs Predicted Active Power")
# plt.plot([0, max(pandas_df["active_power"])], [0, max(pandas_df["active_power"])], color='red', linestyle='--', linewidth=1.5)
# plt.grid(alpha=0.3)
# plt.tight_layout()
# plt.savefig("actual_vs_predicted.png")
# plt.show()
