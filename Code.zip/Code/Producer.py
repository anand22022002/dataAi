from pyspark.sql import SparkSession
from pyspark.sql.functions import to_json, struct

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("KafkaProducer") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.1") \
    .getOrCreate()

# Read the CSV file (Ensure correct path)
df = spark.read.option("header", "true") \
    .option("inferSchema", "true") \
    .csv("/home/xs-514ansana/kafka/Code/Data/dataset.csv")

# Convert DataFrame to JSON format
json_df = df.select(to_json(struct([df[col] for col in df.columns])).alias("value"))

# Kafka Configurations
KAFKA_BROKER = "localhost:9092"
KAFKA_TOPIC = "new-wind-data"

# Write Data to Kafka Topic
try:
    json_df.write \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_BROKER) \
        .option("topic", KAFKA_TOPIC) \
        .mode("append") \
        .save()
    
    print(f"Data successfully sent to Kafka topic '{KAFKA_TOPIC}'")

except Exception as e:
    print(f"Error sending data to Kafka: {e}")

# Stop Spark Session
spark.stop()