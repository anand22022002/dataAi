
from pyspark.sql import SparkSession
from pyspark.sql.functions import countDistinct, hour, avg, col, when, broadcast,explode,map_from_arrays,collect_list
from pyspark.sql.types import StructType, StructField, StringType

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("WindPowerAnalysis") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:2.1.0") \
    .getOrCreate()

# Load the Delta Table
delta_table_path = "/home/xs-514ansana/delta/tables/new_wind_data"
delta_df = spark.read.format("delta").load(delta_table_path)

# Count the total number of rows in the dataset
total_count = delta_df.count()
print(f"Total rows in the dataset: {total_count}")

# === Query 1: Distinct Count of signal_ts Per Day ===
distinct_count_df = delta_df.groupBy("signal_date").agg(countDistinct("signal_ts"))
print("\n=== Query 1: Distinct Count of signal_ts Per Day ===")
distinct_count_df.show(truncate=False)

# Count the total number of rows in the dataset
total_count = distinct_count_df.count()
print(f"Total rows in the dataset: {total_count}")

# === Query 2: Calculate Average Value of All Signals Per Hour ===
avg_per_hour_df = delta_df.withColumn("hour", hour("signal_ts")) \
    .groupBy("signal_date", "hour") \
    .agg(
        avg(col("signals")["LV ActivePower (kW)"]).alias("avg_active_power"),
        avg(col("signals")["Wind Speed (m/s)"]).alias("avg_wind_speed"),
        avg(col("signals")["Theoretical_Power_Curve (KWh)"]).alias("avg_power_curve"),
        avg(col("signals")["Wind Direction (°)"]).alias("avg_wind_direction")
    )

print("\n=== Query 2: Average Value of All Signals Per Hour ===")
avg_per_hour_df.show(truncate=False)

# === Query 3: Add `generation_indicator` Column ===
indicator_df = delta_df.withColumn(
    "generation_indicator",
    when(col("signals")["LV ActivePower (kW)"] < 200, "Low")
    .when((col("signals")["LV ActivePower (kW)"] >= 200) & (col("signals")["LV ActivePower (kW)"] < 600), "Medium")
    .when((col("signals")["LV ActivePower (kW)"] >= 600) & (col("signals")["LV ActivePower (kW)"] < 1000), "High")
    .otherwise("Exceptional")
)

print("\n=== Query 3: Add `generation_indicator` Column ===")
indicator_df.select("signal_date", "signal_ts", "signals", "generation_indicator").show(truncate=False)


# Count the total number of rows in the dataset
total_count = indicator_df.count()
print(f"Total rows in the dataset: {total_count}")

# === Query 4: Create New DataFrame for Signal Mappings ===
signal_mapping_schema = StructType([
    StructField("sig_name", StringType(), True),
    StructField("sig_mapping_name", StringType(), True)
])

signal_mapping_data = [
    {"sig_name": "LV ActivePower (kW)", "sig_mapping_name": "active_power_average"},
    {"sig_name": "Wind Speed (m/s)", "sig_mapping_name": "wind_speed_average"},
    {"sig_name": "Theoretical_Power_Curve (KWh)", "sig_mapping_name": "theo_power_curve_average"},
    {"sig_name": "Wind Direction (°)", "sig_mapping_name": "wind_direction_average"}
]

signal_mapping_df = spark.createDataFrame(signal_mapping_data, schema=signal_mapping_schema)

print("\n=== Query 4: Signal Mapping DataFrame ===")
signal_mapping_df.show(truncate=False)



# Perform Broadcast Join
# Step 1: Explode the signals column (MapType) into individual rows
exploded_df = indicator_df.select(
    "signal_date", "signal_ts", "create_date", "create_ts", 
    explode("signals").alias("signal_name", "signal_value"),  # Explode key-value pairs
    "generation_indicator"
)

# Step 2: Perform broadcast join to map signal names to their new names
renamed_signals_df = exploded_df.join(
    broadcast(signal_mapping_df),  # Broadcast the mapping DataFrame
    exploded_df["signal_name"] == signal_mapping_df["sig_name"],  # Match signal names
    "inner"  # Join type
).drop("sig_name") \
 .withColumnRenamed("sig_mapping_name", "mapped_signal_name")

# Step 3: Rebuild the signals column with renamed signal names
# Group by the necessary columns
rebuilt_signals_df = renamed_signals_df.groupBy(
    "signal_date", "signal_ts", "create_date", "create_ts", "generation_indicator"
).agg(
    map_from_arrays(
        collect_list(col("mapped_signal_name")),  # Aggregate all mapped signal names
        collect_list(col("signal_value"))         # Aggregate all signal values
    ).alias("signals")  # Rebuild signals column
)

# Display the final DataFrame
print("\n=== Final DataFrame with Updated Signal Names ===")
rebuilt_signals_df.select("signal_date", "signal_ts", "signals", "generation_indicator").show(truncate=False)

# Count the total number of rows in the dataset
total_count = rebuilt_signals_df.count()
print(f"Total rows in the dataset: {total_count}")